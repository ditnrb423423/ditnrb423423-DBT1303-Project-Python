from flask import Flask,render_template,request,redirect,url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app=Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///db.security'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
db=SQLAlchemy(app)

class Security(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    crime=db.Column(db.String(200))
    description=db.Column(db.String(255))
    carea=db.Column(db.String(200))
    doc=db.Column(db.String(200))
    status=db.Column(db.Boolean)
    
    def __init__(self,crime,description,carea,doc,status):
        self.crime=crime
        self.description=description
        self.carea=carea
        self.doc=doc
        self.status=status
    def __repr__(self):
        return '<Crime %r>' % self.crime
        
with app.app_context():
    db.create_all()

@app.route('/')

def index():
    sec_list=Security.query.all()
    return render_template('index.html',sec_list=sec_list)

@app.route("/add" ,methods=["POST"])
def add():
    crime = request.form.get("crime")
    description=request.form.get("description")
    carea = request.form.get("carea")
    doc=request.form.get("doc")
    status=request.form.get("status")
    
    new_list=Security(crime=crime,description=description,carea=carea,doc=doc,status=status)
    db.session.add(new_list)
    db.session.commit()
    return redirect(url_for("index"))
"""
@app.route('/update/<int:/sec_id>')
def update(sec_id):
    sec=Security.query.get(sec_id)
    sec.done=not sec.done
    db.session.commit()
    return redirect(url_for("home"))
"""
@app.route('/delete/<int:sec_id>')

def delete(sec_id):
    sec=Security.query.get(sec_id)
    db.session.delete(sec)
    db.session.commit()
    return redirect(url_for("index"))

if __name__=="__main__":

    app.run(debug=True)