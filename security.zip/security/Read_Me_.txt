We have used python and Flask library with Sq light database
step 1:
Create virtual environment
    1. create a folder
    2. On the CMD, cd to the folder created in 1
    3. Create virtual environment
        python -m venv .venv
    4. Activate virtual environment
        cd .venv
        cd Scripts
        Then activate the virtual environment
            activate
Within the activate environment, use the following command to install Flask
        pip install Flask
To run the program use the code below
    flask --app hello run.